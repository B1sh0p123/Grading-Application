package com.sasanka.application.gradingapplicationdemo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DBCollection implements CommandLineRunner {
    private AssignRepository assignRepository;

    public DBCollection(AssignRepository assignRepository){
        this.assignRepository = assignRepository;
    }
    @Override
    public void run(String... string) throws Exception{
        Assignment oop = new Assignment(
                "Object Oriented Programming",
                Arrays.asList(
                        new Questions(1, "What is inheritance?", "Acquiring properties and behaviors of a parent object.",true),
                        new Questions(2, "What is method overloading?", "More than one method with same name but different parameter.", true)
                )
        );

        Assignment database = new Assignment(
                "Database Management System",
                Arrays.asList(
                        new Questions(1, "What is inheritance?", "Acquiring properties and behaviors of a parent object.",true),
                        new Questions(2, "What is method overloading?", "More than one method with same name.", false)
                )
        );

        //This is used to delete all assignments.
        this.assignRepository.deleteAll();

        //This is executed to add the assignments in the database.
        List<Assignment> assignments = Arrays.asList(oop, database);
        this.assignRepository.save(assignments);

        


    }
}
