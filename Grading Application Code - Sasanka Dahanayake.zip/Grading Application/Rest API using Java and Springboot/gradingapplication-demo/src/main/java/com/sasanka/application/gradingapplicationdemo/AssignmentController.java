package com.sasanka.application.gradingapplicationdemo;

import org.springframework.web.bind.annotation.*;

import java.util.List;

//Used to collect specific assignments and it's information
@RestController
@RequestMapping("/assignments")
public class AssignmentController {
    private AssignRepository assignRepository;

    public AssignmentController(AssignRepository assignRepository){
        this.assignRepository = assignRepository;
    }

    //Used to collect all the assignments and their information
    @GetMapping("/all")
    public List<Assignment> getAll(){
        List<Assignment> assignments = this.assignRepository.findAll();

        return assignments;
    }

    //Method used to insert a record in the database
    @PutMapping
    public void insert(@RequestBody Assignment assignment){
        this.assignRepository.insert(assignment);
    }

    //method used to update a record in the database
    @PostMapping
    public void update(@RequestBody Assignment assignment){
        this.assignRepository.save(assignment);
    }

    public void delete(@PathVariable("id") String id){
        this.assignRepository.delete(id);
    }

    //Finding an assignment by ID
    @GetMapping("/{id}")
    public Assignment getById(@PathVariable("id") String id){
        Assignment assignment = this.assignRepository.findById(id);

        return assignment;
    }

    //Finding an assignment by the module
    @GetMapping
    public List<Assignment> getByModule(@PathVariable("moduke") String module){
        List<Assignment> assignments = this.assignRepository.findByModule(module);

        return assignments;
    }


}
