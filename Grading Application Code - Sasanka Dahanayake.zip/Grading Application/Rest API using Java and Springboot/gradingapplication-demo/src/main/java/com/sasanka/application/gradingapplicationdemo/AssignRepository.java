package com.sasanka.application.gradingapplicationdemo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

//MongoDB Repository to handle the CRUD operations.
@Repository
public interface AssignRepository extends MongoRepository<Assignment,String> {
    Assignment findById(String id);
    List<Assignment> findByModule(String module);

}
