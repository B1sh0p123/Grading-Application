package com.sasanka.application.gradingapplicationdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradingapplicationDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(GradingapplicationDemoApplication.class, args);
    }

}
