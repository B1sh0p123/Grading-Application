package com.sasanka.application.gradingapplicationdemo;

public class Questions {

    private int questionNo;
    private String question;
    private String answer;
    private boolean result;

    protected Questions(){

    }

    public Questions(int questionNo, String question, String answer, boolean result){

        this.questionNo = questionNo;
        this.question = question;
        this.answer = answer;
        this.result = result;

    }

    public int getQuestionNo() {
        return questionNo;
    }

    public void setQuestionNo(int questionNo) {
        this.questionNo = questionNo;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public boolean isResult(){
        return result;
    }


    @Override
    public String toString() {
        return "Questions{" +
                "questionNo=" + questionNo +
                ", question=" + question +
                ", answer='" + answer + '\'' +
                '}';
    }
}
