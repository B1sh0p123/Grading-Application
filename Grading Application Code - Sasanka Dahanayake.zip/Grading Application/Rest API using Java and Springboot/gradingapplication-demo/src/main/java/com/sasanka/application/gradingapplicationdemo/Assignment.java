package com.sasanka.application.gradingapplicationdemo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

//Since Assignment is our aggregate root, this is the entity we will apply our MongoDB specific annotations.
//@Document annotation used to let MongoDB to treat as a document and store it in a collection.
@Document(collection = "Assignments")
public class Assignment {

    //In MongoDB, the ID is not an integer value. By default, MongoDB uses a string to defer identifiers.
    @Id
    private String assignID;
    private String module;
    private List<Questions> questions;

    protected Assignment(){

        this.questions = new ArrayList<>();

    }
     public Assignment(String module, List<Questions> questions){

        this.module = module;
        this.questions = questions;

     }

    public String getAssignID() {
        return assignID;
    }

    public void setAssignID(String assignID) {
        this.assignID = assignID;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public List<Questions> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Questions> questions) {
        this.questions = questions;
    }

    @Override
    public String toString() {
        return "Assignment{" +
                "assignID=" + assignID +
                ", module='" + module + '\'' +
                ", questions=" + questions +
                '}';
    }
}
