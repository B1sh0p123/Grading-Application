package com.sasanka.application.gradingapplicationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradingapplicationDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
